function secondMax(arr){

    var largest = Number.MIN_VALUE;
    var second = Number.MIN_VALUE;
  
  
    if(arr.length < 2){
      console.log("Error");
      return;
    }
    else{
  
      for(let i = 0; i < arr.length; i++){
        var number = arr[i];
        if(number > largest){
          second = largest;
          largest = number;
        }
      }
    }
    return second;    
}
  