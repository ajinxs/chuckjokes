function FizzBuzz(n){
    for(var i = 1; i < n; i++){
        
        while(!(i % 3)){
            console.log("fizz");
            break;
        }
        
        while(!(i % 5)){
            console.log("buzz");
            break;
        }
        
        while(i % 3 && i % 5){
            console.log(i);
            break;
        }
        //console.log(" ");
    }
}
  